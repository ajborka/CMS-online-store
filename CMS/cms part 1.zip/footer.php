<address><span class = "last_modified">Last modified <?php print date("F d Y g:iA", getlastmod()); ?></span></address>
  <p class = "validation_img">
    <a href="http://validator.w3.org/check?uri=referer"><img
      src="http://www.w3.org/Icons/valid-xhtml10" alt="Valid XHTML 1.0 Strict" height="31" width="88" /></a>
  </p>
</body>
</html>